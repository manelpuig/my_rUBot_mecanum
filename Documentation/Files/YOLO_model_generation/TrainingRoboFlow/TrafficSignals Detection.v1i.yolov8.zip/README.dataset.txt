# TrafficSignals Detection > 2025-06-02 5:13pm
https://universe.roboflow.com/trafficsignals-1sjvw/trafficsignals-detection

Provided by a Roboflow user
License: CC BY 4.0

